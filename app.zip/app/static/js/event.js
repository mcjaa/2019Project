

$(document).ready(function() {
  console.log("ready!");

  $('#btnExe').on('click', function() {

    $.ajax({
        url: '/news',
        dataType: 'json',
        data: {'kwd' : $('#kwd').val()},

        // data : JSON.stringify( {'kwd': $('#kwd').val(), 'id': 100}, encode("utf-8")),

        type: 'POST',

        success: function(results) {

            // $('#table1').DataTable();
            // $('#table1').dataTable.fnClearTable();
            // $('#table1').dataTable().fnAddData(results);
            //
            // $.each(results, function(){
            //     $('#table1').append("<tr><td>"+this.date+"</td><td>"+this.title+"</td></tr>");
            // });
            
            // $("#table1").DataTable().clear();
            // oTable.addData();
            $.each(results, function(index, entry){
                $('#table1').append("</td><td>"+entry.date+"</td><td>"+entry.title+"</td><td>"+entry.text+"</td></tr>");
            });
        }
        ,
        error: function(error){
            console.log(error);
        }
    });
  });
});
