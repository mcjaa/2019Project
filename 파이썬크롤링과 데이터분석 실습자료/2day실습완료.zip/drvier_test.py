from selenium import webdriver
from selenium.webdriver.common.keys import Keys

#chromedriver = 'c:/python/chromedriver.exe'
#drvier = webdriver.Chrome(chromedriver)

phantom = 'C:/python/phantomjs-2.1.1-windows/bin/phantomjs.exe'
driver = webdriver.PhantomJS(phantom)

driver.get('http://www.python.org')

print(driver.current_url)
print(driver.title)

elem = driver.find_element_by_name('q')

elem.clear()

elem.send_keys('python')

elem.send_keys(Keys.RETURN)

driver.set_window_size(1400,1000)

# 크롬 드라이버의 경우에는 동작하지 않음
elem.screenshot('python_img1.png')

#크롬 드라이버와 팬텀드라이버의 경우에 모두 동작
driver.save_screenshot('python_img2.png')

assert 'No results found.' not in driver.page_source

driver.quit()