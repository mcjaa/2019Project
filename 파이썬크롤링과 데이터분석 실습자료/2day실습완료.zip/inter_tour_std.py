from selenium import webdriver as wd
from selenium.webdriver.common.by import By
# 명시적 대기를 위해 
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os 

main_url = 'http://tour.interpark.com/'
keyword  = '스페인'
# 상품 정보를 담는 리스트
tour_list = []

#TODO1. Chrome 드라이버 생성
driver   = wd.Chrome(executable_path='C:\\python\\chromedriver.exe')

# PhantomJS
# driver   = wd.PhantomJS(executable_path='./phantomjs')

#TODO2. 사이트 접속 (get)
driver.get(main_url)

#TODO3. 검색창을 찾아서 검색어 입력
# id : SearchGNBText
driver.find_element_by_id('SearchGNBText').send_keys(keyword)

#TODO4. 수정할경우 => 뒤에 내용이 붙어버림 => .clear() -> send_keys('내용')
# 검색 버튼 클릭
driver.find_element_by_css_selector('button.search-btn').click()

# 잠시 대기 => 페이가 로드되고 나서 즉각적으로 데이터를 획득 하는 행위는 
# 명시적 대기 => 특정 요소가 로케이트(발결된때까지) 대기
try:
    #TODO5.
    element = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CLASS_NAME, "oTravelBox"))
    )
except Exception as e:
    print( '오류 발생', e)

# 명시적으로 대기를 하던 암묵적으로 대기를 하던
# 화면이 넘어가면 꼭 대기를 해야함. 화면과 화면 넘어갈때 꼭 써야 할 부분

driver.implicitly_wait( 10 )

# 절대기 대기 => time.sleep(10) -> 클라우드 페어(디도스 방어  솔루션)

# 더보기 눌러서 => 게시판 진입
# > 는 직계자식. 태그를 보면서..

driver.find_element_by_css_selector('.oTravelBox>.boxList>.moreBtnWrap>.moreBtn').click()

# TODO6. 파일 생성
wfile = open(os.getcwd() + '/tour_result_all.txt', mode='w', encoding='utf-8')

for page in range(1, 2):#18): # 너무 오래 걸리니깐 2로 테스트
#for page in range(1, 22):#18):
    try:
        # 자바스크립트 구동하기
        # 파이썬 문자열 포매팅 사용
        driver.execute_script("searchModule.SetCategoryList(%s, '')" % page)
        # 강제로 2초 정도 끊음
        time.sleep(2)

        # TODO7.페이지 이동 메시지 화면 출력
        print("%s 페이지 이동" % page)

        # TODO8.페이지 이동 메시지 파일 출력
        wfile.write("%s 페이지 이동" % page+"======"+ '\n')

        boxItems = driver.find_elements_by_css_selector('.oTravelBox>.boxList>li')

        # 상품 하나 하나 접근
        for li in boxItems:
            print( '썸네일', li.find_element_by_css_selector('img').get_attribute('src') )
            wfile.write('썸네일 '+":"+ li.find_element_by_css_selector('img').get_attribute('src') + '\n')

            # print( '링크', li.find_element_by_css_selector('a').get_attribute('onclick') )
            # wfile.write('링크 '+":"+ li.find_element_by_css_selector('a').get_attribute('onclick') + '\n')

            link = li.find_element_by_css_selector('a').get_attribute('onclick')
            arr = link.split(',')
            if arr:
                link = arr[0].replace('searchModule.OnClickDetail(', '')
                detail_url = link[1:-1]
            print( '링크', detail_url )
            wfile.write('링크 '+":"+ detail_url + '\n')

            print( '상품명', li.find_element_by_css_selector('h5.proTit').text )
            wfile.write('상품명 '+":"+ li.find_element_by_css_selector('h5.proTit').text + '\n')
            print( '코멘트', li.find_element_by_css_selector('.proSub').text )
            wfile.write('코멘트 '+":"+ li.find_element_by_css_selector('.proSub').text + '\n')
            print( '가격',   li.find_element_by_css_selector('.proPrice').text )
            wfile.write( '가격 '+":"+   li.find_element_by_css_selector('.proPrice').text + '\n')

            # 한 칸 띄면 자손
            for info in li.find_elements_by_css_selector('.info-row .proInfo'):
                print(  info.text )
                wfile.write(info.text + '\n')

            print('='*100)# 라인 출력
            wfile.write('='*100 + '\n')

    except Exception as e1:
        print( '오류', e1 )

# TODO9.종료

wfile.close()
driver.close()
driver.quit()

import sys
sys.exit()
