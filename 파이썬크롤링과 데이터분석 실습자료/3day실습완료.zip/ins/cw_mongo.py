import tweepy
import json
from pymongo import MongoClient
from openAPI.config import *

MONGO_HOST= 'mongodb://localhost/twitterdb'  
                                             
 
WORDS = ['#bigdata', '#AI', '#datascience', '#machinelearning', '#ml', '#iot']
 
CONSUMER_KEY = consumer_key
CONSUMER_SECRET = consumer_secret
ACCESS_TOKEN = access_token
ACCESS_TOKEN_SECRET = access_token_secret
 
 
class MyStreamListener(tweepy.StreamListener):
 
    def on_connect(self):
        print("You are now connected to the streaming API.")
 
    def on_error(self, status_code):
        print('An Error has occured: ' + repr(status_code))
        return False
 
    def on_data(self, data):
        try:
            client = MongoClient(MONGO_HOST)     
            db = client.twitterdb
            datajson = json.loads(data)
            created_at = datajson['created_at']          
            print("Tweet collected at " + str(created_at))      
            db.twitter_search.insert(datajson)
        except Exception as e:
           print(e)
 
myauth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
myauth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)

mylistener = MyStreamListener(api=tweepy.API(wait_on_rate_limit=True))
streamer = tweepy.Stream(auth=myauth, listener=mylistener)
print("Tracking: " + str(WORDS))
streamer.filter(track=WORDS)
