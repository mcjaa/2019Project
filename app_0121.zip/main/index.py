# file name : index.py
# pwd : /project_name/app/main/index.py

from flask import Blueprint, request, render_template, flash, redirect, url_for, render_template_string
from flask import current_app as app
from flask.json import jsonify
import json

import app.main.News_filter as newsfiltering

main = Blueprint('main', __name__, url_prefix='/')


@main.route('/main', methods=['GET'])
def index():
    testData = 'testData Array'
    # /main/index.html은 사실 /project_name/app/templates/main/index.html을 가리킵니다.
    return render_template('/main/index.html', Param_1=testData)

@main.route('/report', methods=['GET'])
def report():
    kwd_list = ['반도체', '식품', 'IT']
    # /main/index.html은 사실 /project_name/app/templates/main/index.html을 가리킵니다.
    return render_template('/main/report.html', kwd_list=kwd_list)

@main.route('/financial_report', methods=['GET'])
def financial_report():
    kwd_list = ['반도체', '식품', 'IT']
    # /main/index.html은 사실 /project_name/app/templates/main/index.html을 가리킵니다.
    return render_template('/main/report2.html', kwd_list=kwd_list)


@main.route('/TB_news', methods=['GET','POST'])
def tb_news():
    _kwd = request.form['kwd']
    _subject = request.form['subject']
    print(_kwd)
    print(_subject)

    crawler = newsfiltering.News(_kwd, _subject)
    res = crawler.get_news()
    print("-------------")
    print(res)
    return res.to_json(orient='records')
