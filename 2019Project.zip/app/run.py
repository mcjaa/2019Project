# file name : run.py
# pwd : /project_name/run.py

from app import app

# app.run(host="0.0.0.0", port="80")
app.run()