# file name : index.py
# pwd : /project_name/app/main/index.py

from flask import Blueprint, request, render_template, flash, redirect, url_for, render_template_string
from flask import current_app as app
from flask.json import jsonify
import json

import app.main.TopicModel as newscrawling

main = Blueprint('main', __name__, url_prefix='/')


@main.route('/main', methods=['GET'])
def index():
    testData = 'testData Array'
    # /main/index.html은 사실 /project_name/app/templates/main/index.html을 가리킵니다.
    return render_template('/main/index.html', Param_1=testData)

@main.route('/report', methods=['GET'])
def report():
    kwd_list = ['반도체', '자율주행', '리츠', '드론', '북한']
    # /main/index.html은 사실 /project_name/app/templates/main/index.html을 가리킵니다.
    return render_template('/main/report.html', kwd_list=kwd_list)

@main.route('/news', methods=['GET','POST'])
def news():
    _kwd = request.form['kwd']
    print(_kwd)

    crawler = newscrawling.Crawling(_kwd)
    data = crawler.get_data_main()
    print("-------------")
    print(data)
    return data.to_json(orient='records')
    # return render_template_string('/main/report.html', news_data=data)
