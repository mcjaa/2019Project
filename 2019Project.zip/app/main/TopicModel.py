import requests
from bs4 import BeautifulSoup
from urllib import parse
import pandas as pd


# 증권리포트 제목, 내용, url을 분리, 저장하는 함수

class Crawling():
    def __init__(self, kwd):
        self.searchword = kwd
        self.url = ''

    def get_report_inf(self, temp):
        headers = {'Accept-Encoding': 'deflate'}
        res = requests.get(url=self.url, headers=headers)
        # BeautifulSoup을 이용해 웹 html을 파싱
        soup = BeautifulSoup(res.content, 'html.parser', from_encoding='euc-kr')  # , from_encoding="euc-kr"
        title = soup.find('div', {'id': 'Titless'}).text
        text = soup.find('div', {'id': 'Conts'}).text
        report_data = {}
        report_data['title'] = title.strip()  # 기사 제목
        text = text.replace("\r", " ").strip()
        report_data['text'] = text.replace("<br>", " ").strip()  # 기사 내용에서 줄바꿈을 지우고, 좌우 공백 제거
        #     report_data['text'] = text.strip()  # 기사 내용에서 줄바꿈을 지우고, 좌우 공백 제거
        report_data['url'] = self.url  # 기사 링크

        res.encoding = None
        h_data = pd.read_html(res.text)
        report_data['date'] = h_data[2].iloc[0, 0].split('|')[2].strip()
        return report_data


    # 증권리포트 크롤링 data를 반환하는 함수

    def get_report_list(self, query,  # 검색어
                        page=1  # 뉴스 리스트 페이지
                        ):
        url = 'http://vip.mk.co.kr/newSt/news/news_list2.php?sCode=110&p_page={page}&search=' + parse.quote(query,
                                                                                                            encoding='euc-kr')

        res = requests.get(url.format(page=page))

        # BeautifulSoup을 이용해 웹 html을 파싱
        soup = BeautifulSoup(res.content, 'html.parser')
        # print(soup)

        # html 구조에서 해당 기사로 접근할 수 있는 url을 추출
        table = soup.find('table', {'class': 'table_6'})
        alinks = table.findAll('a')

        report_list = []

        for alink in alinks[:1]:
            alink['href'] = alink['href'].replace("./", "http://vip.mk.co.kr/newSt/news/")
            report_url = alink['href']
            print(report_url)
            self.url = report_url
            a = self.get_report_inf(self)
            report_list.append(self.get_report_inf( self))

        return report_list

    def get_data_main(self):
        #증권리포트 크롤링 실행
        articles = []
        articles.extend(self.get_report_list(self.searchword, page=1))
        pd1 = pd.DataFrame(articles)
        pd1 = pd1.loc[:,['date','title','text']]
        return pd1

