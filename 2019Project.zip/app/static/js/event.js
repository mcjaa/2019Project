$(function(){
	$('#btnExe').click(function(){

		$.ajax({
            url: '/news',
            data: {'kwd' : $('#kwd').val()},
            type: 'POST',
            success: function(data) {
                $("#result").html(data);
                $('#table1').dataTable().fnClearTable();
                $('#table1').dataTable().fnAddData(data);

                $.each(data, function(){
                    $('#table2').append("<tr><td>"+this.date+"</td><td>"+this.title+"</td></tr>");
                });

                 $.each(data, function(index, entry){
                    $('#table2').append("<tr><td>"+entry.date+"</td><td>"+entry.title+"</td></tr>");
                });
            }
            ,
            error: function(error){
                console.log(error);
            }
        });
	});
});
