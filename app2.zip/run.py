# file name : run.py
# pwd : /project_name/run.py

from app import app
from flask import Flask, render_template, request, Response, jsonify

####  setup routes  ####
@app.route('/')
def index():
    return render_template('site_template.html')

app.run(port="5000", debug = True)
