import pandas as pd
import os


class News():
    def __init__(self, kwd, subject):
        self.searchword = kwd
        self.subject = subject

    def get_news(self):
        df_name = os.getcwd() +"/data/"+self.subject+"_news_1031.csv"
        df = pd.read_csv(df_name)
        df = df[(df['text'].str.contains(self.searchword)) | (df['title'].str.contains(self.searchword))]
        return df[:5]

