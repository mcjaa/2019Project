$(document).ready(function() {
  console.log("ready60!");

    $('#btnExe').on('click', function() {
        $("#topicM").empty();
        var load_add;
        if($("#kwd").val() == '반도체'){
            load_add ="/static/html/theBell_topicM_1.html";
        }else if($("#kwd").val() == '식품'){
            load_add ="/static/html/theBell_topicM_2.html";
        }
        console.log("load_add====> %s",load_add);
        $("#topicM").load(load_add);
    });

  $('#table1').on('click','tr.clickable', function() {
			// 현재 클릭된 Row(<tr>)
			var tr = $(this);
			var td = tr.children();

			// tr.text()는 클릭된 Row 즉 tr에 있는 모든 값을 가져온다.
			console.log("클릭한 Row의 모든 데이터 : "+tr.text());

			console.log("--------------------");
			console.log(td.eq(2).text());
			console.log(td.eq(3).text());
			$("#summary").text(td.eq(2).text());


    });



//    $('#btnExe').on('click', function() {
//        $.ajax({
//                url: '/TB_news',
//                dataType: 'json',
//                data: {'kwd' : 'SK'},
//                type: 'POST',
//                success: function(results) {
//                    $("#table1_tbody").find("tr").remove();
//
//                    $.each(results, function(index, entry){
//                        $('#table1_tbody').append("<tr class='clickable'><td>"+entry.date+"</td><td>"+entry.title+"</td><td class='hide'>"+entry.text+"</td><td class='hide'>"+entry.url+"</td></tr><");
//                    });
//                },
//                error: function(error){
//                    console.log(error);
//                }
//            });
//
//    });
});


//$('#btnExe').on('click', function() {
//    console.log("ready44!");
//    $("#topicM").empty();
//    $("#topicM").load("/static/html/theBell_topicM.html");
//});


//$('#table1_tbody td').on('click', function() {
//            console.log("pp");
//
//			// 현재 클릭된 Row(<tr>)
//			var tr = $(this);
//			console.log(tr);
//
//});
//$('#table1 tr').on('click', function() {
//            console.log("passap");
//
//			// 현재 클릭된 Row(<tr>)
//			var tr = $(this);
//			console.log(tr);
//
//});
//
////$('#table1').on('click', function() {
////            console.log("asdasd");
////            console.log($(this).closest("tr").index());
////
////});
//
//$('#btnExe').on('click', function() {
//    $.ajax({
//            url: '/TB_news',
//            dataType: 'json',
//            data: {'kwd' : 'SK'},
//            type: 'POST',
//            success: function(results) {
//                $("#table1").find("tr").remove();
//                $('#table1').append("<thead><tr align='center' height='15'><th width='160' >Date</th><th >Title</th></tr></thead>");
//
//
//                $.each(results, function(index, entry){
//                    $('#table1').append("<tbody><tr><td>"+entry.date+"</td><td>"+entry.title+"</td><td class='hide'>"+entry.text+"</td><td class='hide'>"+entry.url+"</td></tr></tbody>");
//                });
//            },
//            error: function(error){
//                console.log(error);
//            }
//        });
//
//});