from flask import Flask, render_template, request, Response, jsonify
import matplotlib
# matplotlib.use('Agg')
# import warnings
# warnings.filterwarnings('ignore')

import matplotlib.pyplot as plt

plt.ioff()
from threading import Lock

lock = Lock()
import json
import Model
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SelectField, BooleanField, validators

# pseudoDatabase
dataset = None
prevCompany = None

app = Flask(__name__)
app.secret_key = 'donttellnobody'


class StockForm(FlaskForm):
    stock = StringField('Stock', [validators.DataRequired("Please enter a stock name.")])


# Routes
@app.route("/")
def home():
    return render_template("home.html")


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/Market_Analysis', methods=['GET', 'POST'])
def Market_Analysis():
    form = StockForm()

    if request.method == 'POST':

        try:

            stockname = request.form['stock']

            htmlFormOfGraph_kospi = Model.generateChart_kospi()
            htmlFormOfGraph_exchange = Model.generateChart_exchange()
            htmlFormOfGraph_industry = Model.generateChart_industry()
            htmlFormOfGraph_stock = Model.generateChart_stock()

        except Exception as error:
            return str(error)
        else:

            return render_template('Market_Analysis.html',
                                   form=form,
                                   div_stock = htmlFormOfGraph_stock,
                                   div_kospi = htmlFormOfGraph_kospi,
                                   div_industry = htmlFormOfGraph_industry,
                                   div_exchange=htmlFormOfGraph_exchange

                                   )

    elif request.method == 'GET':

        return render_template('Market_Analysis.html', form=form)

    return render_template('Market_Analysis.html')


@app.route('/Market_Analysis_Action', methods=['GET', 'POST'])
def Market_Analysis_Action():
    form = StockForm()

    if request.method == 'POST':

        try:

            stockname = request.form['stock']

            htmlFormOfGraph_currentChart = Model.generateChart_currentChart()
            htmlFormOfGraph_patternAll = Model.generateChart_patternAll()
            htmlFormOfGraph_patternChoice = Model.generateChart_patternChoice()


        except Exception as error:
            return str(error)
        else:

            return render_template('Market_Analysis_Action.html',
                                   form=form,
                                   div_patternAll = htmlFormOfGraph_patternAll,
                                   div_currentChart = htmlFormOfGraph_currentChart,
                                   div_patternChoice = htmlFormOfGraph_patternChoice)

    elif request.method == 'GET':

        return render_template('Market_Analysis_Action.html', form=form)

    return render_template('Market_Analysis_Action.html')



if __name__ == "__main__":
    app.run(host='0.0.0.0', port=7778 , debug=True)
