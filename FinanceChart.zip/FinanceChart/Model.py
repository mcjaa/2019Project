import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import mpld3
from mpld3 import plugins
import pandas as pd
from datetime import date, datetime, timedelta
import pandas_datareader as wb
import datetime

## 개별주가
def generateChart_stock():
    '''
        Use the data to calculate moving average and plot chart using moving average as label
    :param companyName: Name of the company
    :param data: stock prices
    :return: return chart in html
    '''

    StockPrice_df = pd.read_csv('./Data/SK하이닉스/StockPrice_df.csv', parse_dates=['Date'])
    StockPrice_date_df = pd.read_csv('./Data/SK하이닉스/StockPrice_date_df.csv', parse_dates=['Date'])
    StockPrice_date_df = StockPrice_date_df.set_index("Date")

    max_price = StockPrice_date_df['Price'].max()  # 최고가(y축)
    max_date = StockPrice_date_df[StockPrice_date_df['Price'] == max_price].index[-1]  # 최고가를 형성한 날짜(x축)
    min_price = StockPrice_date_df['Price'].min()  # 최저가(y축)
    min_date = StockPrice_date_df[StockPrice_date_df['Price'] == min_price].index[-1]  # 최저가를 형성한 날짜(x축)

    fig, ax = plt.subplots(figsize=(10, 4))
    StockPrice_date_df['Price'].plot(color='#465678')
    # stockPricePoints = StockPrice_date_df['Price']
    # StockPrice_date_df['20일평균'].plot(color='red', linewidth = '2')
    # StockPrice_date_df['상단'].plot(color = 'gray', linestyle = 'dashed', label = 'upper band')
    # StockPrice_date_df['하단'].plot(color = 'gray', linestyle = 'dashed', label = 'lower band')

    # plt.scatter(max_date, max_price, s=50, c='red')  # 최고가인 날짜에 점을 찍는 것
    # plt.text( max_date + timedelta(days=4), max_price, '최고가({0})'.format(max_date), fontsize=9,  # 최고가인 날짜 표시를 하는 것
    #          verticalalignment='top')
    #
    # plt.scatter(min_date, min_price, s=50, c='red')  # 최저가인 날짜에 점을 찍는 것
    # plt.text( min_date + timedelta(days=4), min_price, '최저가({0})'.format(min_date), fontsize=9,  # 최저가인 날짜 표시를 하는 것
    #          verticalalignment='top')

    plt.legend(fontsize=14)
    # plt.fill_between(StockPrice_date_df.index, StockPrice_date_df['하단'], StockPrice_date_df['상단'], color = 'green', alpha = 0.05)

    plt.title("SK 하이닉", fontsize=10)

    # tooltip = plugins.PointHTMLTooltip(StockPrice_date_df['Price'])
    # plugins.connect(fig, tooltip)
    plt.grid(True)
    plt.axis('off')
    # fig.tight_layout()

    return mpld3.fig_to_html(fig)


##KOSPI 주가
def generateChart_kospi():
    '''
        Use the data to calculate moving average and plot chart using moving average as label
    :param companyName: Name of the company
    :param data: stock prices
    :return: return chart in html
    '''


    start = datetime.datetime(2014, 1, 1)
    end = datetime.datetime(2019, 10, 29)
    df_null = wb.DataReader("^KS11", "yahoo", start, end)
    kospi_df = df_null.dropna()
    kospi_values = kospi_df['Close']

    ##그래프그리기
    fig, ax = plt.subplots(figsize=(10, 2))
    kospi_df['Close'].plot(color='#465678')
    plt.title("KOSPI 지수", fontsize=10)
    # plt.ylabel("WON", fontsize=10)

    plt.legend(fontsize=14)

    # tooltip = plugins.PointHTMLTooltip(kospi_values[0])
    # plugins.connect(fig, tooltip)
    # plugins.connect(fig)
    plt.grid(True)
    # fig.tight_layout()
    plt.axis('off')


    return mpld3.fig_to_html(fig)

##환율지수
def generateChart_exchange():
    '''
        Use the data to calculate moving average and plot chart using moving average as label
    :param companyName: Name of the company
    :param data: stock prices
    :return: return chart in html
    
    '''
    start = datetime.datetime(2014, 1, 1)
    end = datetime.datetime(2019, 10, 29)

    exchagne_df = wb.DataReader("DEXKOUS", "fred", start, end)
    exchagne_df = exchagne_df.dropna()

    # exchange_values = exchagne_df['DEXKOUS']

    ##그래프그리기
    fig, ax = plt.subplots(figsize=(10, 2))
    exchagne_df['DEXKOUS'].plot(color='#465678')
    plt.title("환율 USD", fontsize=10)
    # plt.ylabel("WON", fontsize=10)

    plt.legend(fontsize=14)

    # tooltip = plugins.PointHTMLTooltip(exchange_values[0])
    # plugins.connect(fig, tooltip)
    # plugins.connect(fig)
    plt.grid(True)
    # fig.tight_layout()
    plt.axis('off')

    return mpld3.fig_to_html(fig)

##산업지수
def generateChart_industry():
    '''
        Use the data to calculate moving average and plot chart using moving average as label
    :param companyName: Name of the company
    :param data: stock prices
    :return: return chart in html

    '''

    import FinanceDataReader as fdr
    start = datetime.datetime(2014, 1, 1)
    industry_df = fdr.DataReader('KQ47', start)
    # industry_val = industry_df['Close']

    ##그래프그리기
    fig, ax = plt.subplots(figsize=(10, 2))
    industry_df['Close'].plot(color='#465678')
    plt.title("산업 지수", fontsize=10)
    # plt.ylabel("index", fontsize=10)

    plt.legend(fontsize=14)

    # tooltip = plugins.PointHTMLTooltip(industry_val[0])
    # plugins.connect(fig)
    plt.grid(True)
    # fig.tight_layout()
    plt.axis('off')

    return mpld3.fig_to_html(fig)

##패턴찾기
def generateChart_patternAll():
    '''
        Use the data to calculate moving average and plot chart using moving average as label
    :param companyName: Name of the company
    :param data: stock prices
    :return: return chart in html

    '''
    ##데이터 정
    StockPrice_date_df_last = pd.read_csv('./Data/SK하이닉스/StockPrice_date_df_last.csv', parse_dates=['Date'])
    StockPrice_date_df_last = StockPrice_date_df_last.set_index("Date")
    StockPriceSub2 = pd.read_csv('./Data/SK하이닉스/StockPriceSub2.csv', parse_dates=['Unnamed: 0'])
    StockPriceSub2 = StockPriceSub2.set_index("Unnamed: 0")
    del StockPriceSub2.index.name
    StockPrice_date_df = pd.read_csv('./Data/SK하이닉스/StockPrice_date_df.csv', parse_dates=['Date'])
    StockPrice_date_df = StockPrice_date_df.set_index("Date")
    price_last_pip_list = pd.read_csv('./Data/SK하이닉스/price_last_pip_list.csv', parse_dates=['Date'])
    price_pip_list = pd.read_csv('./Data/SK하이닉스/price_pip_list.csv', parse_dates=['Date'])

    ##그래프그리기
    fig, ax = plt.subplots(figsize=(10, 4))

    StockPrice_date_df['Price'].plot(color='#465678', label='Stock Price')
    StockPrice_date_df_last['Price'].plot(color='r', linewidth=3, label='Latest Sequence')
    StockPriceSub2['Price'].fillna(limit=2, method='ffill').plot(color='b', linewidth=4, dashes=[2, 2],
                                                                 label='Pattern Sequence')
    plt.scatter(price_pip_list['Date'], price_pip_list['Price'], color='b', s=10, alpha=0.5,
                label='Perceptually Important Points')

    plt.title("Pattern in Stock Price", fontsize=10)
    # plt.ylabel("WON", fontsize=10)

    plt.legend(fontsize=14)
    plt.grid(True)


    # tooltip = plugins.PointHTMLTooltip(industry_val[0])
    # plugins.connect(fig)
    # fig.tight_layout()
    plt.axis('off')

    return mpld3.fig_to_html(fig)


##패턴찾
def generateChart_patternChoice():
    '''
        Use the data to calculate moving average and plot chart using moving average as label
    :param companyName: Name of the company
    :param data: stock prices
    :return: return chart in html

    '''
    ##데이터 정
    StockPrice_date_df = pd.read_csv('./Data/SK하이닉스/StockPrice_date_df.csv', parse_dates=['Date'])
    StockPrice_date_df = StockPrice_date_df.set_index("Date")
    StockPriceSub = pd.read_csv('./Data/SK하이닉스/StockPriceSub.csv', parse_dates=['Date'])
    StockPriceSub = StockPriceSub.set_index("Date")
    price_pip_list = pd.read_csv('./Data/SK하이닉스/price_pip_list.csv', parse_dates=['Date'])
    # price_pip_list = pd.read_csv('./Data/SK하이닉스/price_pip_list.csv', parse_dates=['Date'])

    g = StockPriceSub.groupby(['distance', 'startDate'])

    choice_len =len(g.size())

    ax_size = choice_len * 2

    fig, ax = plt.subplots(figsize=(10, ax_size))

    for i, (label, data) in enumerate(g):
        plt.subplot(choice_len, 1, i+1)
        data['Price'].plot(color='#465678', linewidth=2, label='Pattern Sequence')

        StockPrice_date_df[StockPrice_date_df.index > pd.to_datetime(data.index[-2])]['Price'].head(10).plot(
            color='red', linewidth=3, label='Stock Price', dashes=[2, 1])
        ax.set_title("Stock Price sequence | distance: {}".format(round(data.distance[0], 3)), fontsize=20)

        axes = plt.gca()

        x1, x2, y1, y2 = plt.axis()
        axes.set_ylim([y1, y2])

        plt.scatter(price_pip_list['Date'], price_pip_list['Price'], color='b', s=50, alpha=0.5,
                    label='Perceptually Important Points')
        plt.plot(price_pip_list['Date'], price_pip_list['Price'], color='b')

        # plt.ylabel("WON", fontsize=10)
        plt.legend(fontsize=10)
        plt.grid(True)
    # plugins.connect(fig)
    #     fig.tight_layout()
        plt.axis('off')

    return mpld3.fig_to_html(fig)


##최근주가
def generateChart_currentChart():
    '''
        Use the data to calculate moving average and plot chart using moving average as label
    :param companyName: Name of the company
    :param data: stock prices
    :return: return chart in html

    '''
    ##데이터 정
    StockPrice_date_df_last = pd.read_csv('./Data/SK하이닉스/StockPrice_date_df_last.csv', parse_dates=['Date'])
    StockPrice_date_df_last = StockPrice_date_df_last.set_index("Date")
    price_pip_list = pd.read_csv('./Data/SK하이닉스/price_pip_list.csv', parse_dates=['Date'])

    ##그래프그리기
    fig, ax = plt.subplots(figsize=(10, 2))


    StockPrice_date_df_last['Price'].plot(color='#465678', linewidth=2, label='Latest Sequence')
    axes = plt.gca()
    x1, x2, y1, y2 = plt.axis()
    axes.set_ylim([y1, y2])
    plt.scatter(price_pip_list['Date'], price_pip_list['Price'], color='b', s=50, alpha=0.5,
                label='Perceptually Important Points')
    plt.title("Current Price", fontsize=10)

    plt.grid(True)
    # tooltip = plugins.PointHTMLTooltip(industry_val[0])
    # plugins.connect(fig)
    # fig.tight_layout()
    plt.axis('off')

    return mpld3.fig_to_html(fig)
















