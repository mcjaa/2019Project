// $(document).ready(function() {
//   console.log("ready!");
//
//
//   // on form submission ...
//   $('#drawPlot').on('click', function() {
//
//     console.log("the form has beeen submitted");
//
//     // grab values
//
//     $.ajax({
//       type: "POST",
//       url: "/Market_Analysis",
//       dataType: 'json',
//       contentType: 'application/json',
//       beforeSend: function(){
//         // Show image container
//         // $('#results').hide();
//         // $('#results_translate').hide();
//         // $('#loader').show();
//       },
//       success: function(results) {
//         console.log(results);
//
//
//         h='<span style="font-weight:bold">Summary(ENG): </span>'
//         $('#Chart').bind(results)
//
//
//       },
//       error: function(error) {
//         console.log(error)
//       },
//        complete:function(data){
//        // Hide image container
//        //   $('#results').show();
//        //   $('#results_translate').show();
//        //   $("#loader").hide();
//
//       }
//     });
//   });
//
//
//
//   // $('#Abstract_1').on('click', function() {
//   //
//   //   console.log("the form has beeen submitted");
//   //
//   //   // grab values
//   //
//   //   txt = $("#message").val();
//   //   txt=txt.replace(/\"/g, "");
//   //   txt=txt.replace(/\'/g, "");
//   //   //alert($("#message").val())
//   //   console.log(txt)
//   //
//   //   $.ajax({
//   //     type: "POST_1",
//   //     url: "/summary",
//   //     dataType: 'json',
//   //     contentType: 'application/json',
//   //     data : JSON.stringify( {'src': txt, 'id': 100}),
//   //     data : JSON.stringify( {'src': txt, 'id': 100}),
//   //     beforeSend: function(){
//   //       // Show image container
//   //       $('#results').hide();
//   //       $('#results_translate').hide();
//   //       $('#loader').show();
//   //     },
//   //     success: function(results) {
//   //       console.log(results);
//   //
//   //       if (results.tgt.length > 0) {
//   //         h='<span style="font-weight:bold">Summary(ENG): </span>'
//   //         $('#results').html(h+ results.tgt);
//   //
//   //         //번역기 연동(영어 => 한글)=====================================================
//   //         h_translate='<span style="font-weight:bold">Summary(KOR): </span>'
//   //         $('#results_translate').html(h_translate+ results.tgt_kor);
//   //
//   //       } else {
//   //         $('#results').html('Something went terribly wrong! Please try again.')
//   //       }
//   //     },
//   //     error: function(error) {
//   //       console.log(error)
//   //     },
//   //      complete:function(data){
//   //      // Hide image container
//   //        $('#results').show();
//   //        $('#results_translate').show();
//   //        $("#loader").hide();
//   //     }
//   //   });
//   // });
//
//
//
// });
